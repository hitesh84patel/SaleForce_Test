﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SecretFunction
{
    /// <summary>
    /// Class for implementation of Secret function.
    /// </summary>
    public static class SecretClass
    {
        /// <summary>
        /// Secret method with dummy implementation
        /// </summary>
        /// <param name="input">Integer input</param>
        /// <returns>returns integer output</returns>
        public static int Secret(int input)
        {
            return input;
        }
    }
}
