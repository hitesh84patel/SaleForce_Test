﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Salesforce_Test
{
    class Program
    {
        static void Main(string[] args)
        {
            int userValue;
            string input;
            Console.Clear();
            Console.WriteLine("Today is Good day!");
            do
            {
                Console.WriteLine("Press enter your integer input greater than one... ");
                input = Console.ReadLine();
            } while (!int.TryParse(input, out userValue));

            Console.WriteLine("Thanks for your input. Please wait for result... ");

            if (FunctionLibrary.CheckAdditiveFunction(userValue) == true)
            {
                Console.WriteLine("Great! Secret function is additive");
            }
            else
            {
                Console.WriteLine("Secret function is NOT additive");
            }

            //Console.WriteLine(string.Join(",",primeNumbers));

            Console.WriteLine("Press any key to exit... ");
            Console.ReadKey();
        }
    }
}
