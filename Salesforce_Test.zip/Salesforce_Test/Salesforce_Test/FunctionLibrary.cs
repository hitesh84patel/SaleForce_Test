﻿using System.Collections.Generic;
using System.Linq;
using SecretFunction;

namespace Salesforce_Test
{
    /// <summary>
    /// Class containing all utility and main calculation functions
    /// </summary>
    public static class FunctionLibrary
    {
        /// <summary>
        /// the main function to check whether the provided Secret function is additive or not. 
        /// </summary>
        /// <param name="input">Integer user input</param>
        /// <returns>returns True or False</returns>
        public static bool CheckAdditiveFunction(int input)
        {
            if (input < 2)
                return false;
            Dictionary<int, int> secretResults = new Dictionary<int, int>();
            //Get Prime numbers less than user input value
            List<int> primeNumbers = FunctionLibrary.GetPrimeNumbers(input);

            //Get all non-repetitive combinations for prime numbers in question
            var permutations = FunctionLibrary.GetCombinations(primeNumbers, 2);

            //Logic to check if the Secret function is additive
            foreach (var perm in permutations)
            {
                //Here I have used dictionary "secretResults" to store already calculated argument/results combinations
                //to avoid repetitive/redundant calls to "Secret" function
                if (!secretResults.ContainsKey(perm.Sum()))
                {
                    secretResults.Add(perm.Sum(), SecretClass.Secret(perm.Sum()));
                }
                if (!secretResults.ContainsKey(perm.First()))
                {
                    secretResults.Add(perm.First(), SecretClass.Secret(perm.First()));
                }
                if (!secretResults.ContainsKey(perm.Last()))
                {
                    secretResults.Add(perm.Last(), SecretClass.Secret(perm.Last()));
                }

                if (secretResults[perm.Sum()] != (secretResults[perm.First()] + secretResults[perm.Last()]))
                {
                    //return from function on first non-additive result
                    return false;
                }
            }

            return true;
        }

        /// <summary>
        /// Function to get all prime numbers less than user's input
        /// </summary>
        /// <param name="input">Integer user's input</param>
        /// <returns>Returns list of prime numbers</returns>
        public static List<int> GetPrimeNumbers(int input)
        {
            List<int> result = new List<int>();

            if (input == 2)
            {
                result.Add(2);
            }
            else
            {
                result.Add(2);
                //Considering only odd numbers because any even number (except 2) can not be a Prime number. 
                //so no need to take even numbers into consideration.
                int[] oddNumbers = GetOddNumbers(input);

                for (int i = 0; i < oddNumbers.Length; i++)
                {
                    if (oddNumbers[i] > 7)
                    {
                        bool isPrime = true;

                        //taking into account only prime numbers calculated so far to minimize below "foreach" iterations
                        foreach (int prime in result)
                        {
                            if (oddNumbers[i] % prime == 0)
                            {
                                isPrime = false;
                                break;
                            }
                        }

                        if (isPrime == true)
                        {
                            result.Add(oddNumbers[i]);
                        }
                    }
                    else
                    {
                        result.Add(oddNumbers[i]);
                    }
                }
            }
            return result;
        }

        /// <summary>
        /// function to return all odd numbers less than provided input value
        /// </summary>
        /// <param name="input">Interger input</param>
        /// <returns>Returns list of odd numbers</returns>
        public static int[] GetOddNumbers(int input)
        {
            List<int> result = new List<int>();

            for (int i = 3; i < input; i++)
            {
                if (i % 2 != 0)
                {
                    result.Add(i);
                }
            }
            return result.ToArray();
        }

        /// <summary>
        /// Function to calculate all non-repetitive combinations for the provided input number list and provided combination length/count
        /// </summary>
        /// <typeparam name="T">Type of input</typeparam>
        /// <param name="items">List of items for which combinations needs to be calculated</param>
        /// <param name="count">Combination length/count</param>
        /// <returns>Returns all possible combinations</returns>
        public static IEnumerable<IEnumerable<T>> GetCombinations<T>(IEnumerable<T> items, int count)
        {
            int i = 0;
            foreach (var item in items)
            {
                if (count == 1)
                    yield return new T[] { item };
                else
                {
                    foreach (var result in GetCombinations(items.Skip(i + 1), count - 1))
                        yield return new T[] { item }.Concat(result);
                }
                ++i;
            }
        }
    }
}
